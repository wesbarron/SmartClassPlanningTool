from PyPDF2 import PdfFileReader, PdfFileWriter



def getContent(filePath):
    lines = []
    pdf = PdfFileReader(filePath)

    for pageNum in range(pdf.numPages):
        pageObj = pdf.getPage(pageNum)
        txt = pageObj.extractText()
        x=1
        for line in txt.splitlines():
            x=x+1
            #print(line)
            if line.startswith("Remark:") or line.startswith("AREA") or (x%2==0):
                pass
            else:
                line=line.replace("*","")
                lines.append(line)
    return lines