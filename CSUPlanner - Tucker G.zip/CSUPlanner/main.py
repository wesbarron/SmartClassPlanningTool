
import openpyxl
from PyPDF2 import PdfFileReader, PdfFileWriter

file_path = "./Sample_Input3.pdf"

lines = []
def getContent(filePath):
    pdf = PdfFileReader(filePath)
    useableLines = []
    for pageNum in range(pdf.numPages):
        pageObj = pdf.getPage(pageNum)
        #print("Page Number: ",pageNum)
        txt = pageObj.extractText().split("\n") #Split PDF String by \n
        for i in range(len(txt)):
            line= txt[i].split(" ")#split each line of original string into separate words
            for w in range(len(line)-1):
                if (line[w]+" "+line[w+1]== "Credits in" or line[w]+" "+line[w+1]== "Classes in" or line[w]+" "+line[w+1]== "Class in" or line[w]+" "+line[w+1]== "Credit in"  ):
                    useableLines.append(txt[i]) #If the line conatains the word "Classes" or "Credits" that line is added to a list of strings that need to be parsed for class titles
    #print(useableLines)

    return useableLines


def createFromParse(lines):
    Dictionary = {}
    for x in range(len(lines)):
        code= ""
        title=""
        words= lines[x].split(" ")
        if words[-1] == "or":
            pass
        else:
            for w in range(len(words)):
                words[w] = words[w].replace("*","")
                words[w] = words[w].replace("K", "")
                words[w] = words[w].replace("U", "")
                words[w] = words[w].replace("L", "")
                if words[w].isdigit() and len(words[w])>3:
                    code = words[w]
                if words[w].isupper() and len(words[w]) ==4:
                    title = words[w]
            if len(code)>3 and len(title)>3:
                course =Course(title+" "+code,3,False)
                Dictionary[course.CourseNum] = course
                print (course.CourseNum + " " + str(course.CreditHours))
    return Dictionary

def readXL(filePath,parsedDict):
    wb= openpyxl.load_workbook(filePath)
    sheet= wb.active

    col_max= sheet.max_column
    row_max= sheet.max_row
    Dictionary = {}
    for i in range (1,row_max + 1): #Read 1st 2 columns of xl file and create courses accordingly
        CourseNum= sheet.cell(i, 1).value
        Hours= sheet.cell(i,2).value
        #print(CourseNum+ " "+ str(Hours))
        if CourseNum in parsedDict.keys():
            course= Course(CourseNum,Hours,False)
        else:
            course= Course(CourseNum,Hours,True)
        Dictionary[course.CourseNum] = course


    for i in range(1, row_max + 1):
        CourseNum= sheet.cell(i, 1).value
        for y in range(3, col_max+1):
            pre_req = sheet.cell(i, y).value
            if pre_req !="none":
                try:#if the key exists
                    Dictionary[CourseNum].prereq.append(Dictionary[pre_req])#reiterate adding newly created course objects into a list for each of its pre-requisites.
                except:
                    pass
        parsedDict[CourseNum] = Dictionary[CourseNum]
    print(parsedDict["CPSC 5128"].CourseNum +" "+ str(parsedDict["CPSC 5128"].CreditHours) + " Completed: "+ str(parsedDict["CPSC 5128"].isComplete()))
    return parsedDict

#def createSchedules(dictionary):


class Course:
    def __init__(self,CourseNum, CreditHours, completed):
        self.CourseNum = CourseNum
        self.CreditHours = CreditHours
        self.Completed= completed
        self.prereq=[]
        self.takeable= True
    def isComplete(self):
        return self.Completed
    def canBeTaken(self):
        for course in range(len(self.prereq)):
            if(self.prereq[course].isComplete()):
                pass
            else:
                self.takeable=False
        return self.takeable

class Semester:
    def __int__(self,term,hours,dictionary):
        Term=term
        MaxHours=hours

parsed = getContent(file_path)
CoursesDict= createFromParse(parsed)
Final_Dictionary = readXL("./CPSCXL.xlsx", CoursesDict)




# See PyCharm help at https://www.jetbrains.com/help/pycharm/
